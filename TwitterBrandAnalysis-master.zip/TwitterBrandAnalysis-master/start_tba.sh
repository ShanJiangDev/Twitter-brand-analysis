erl -pa ebin deps/*/ebin -config tba -name name@dns -setcookie insert_cookie_here -run main -noshell
