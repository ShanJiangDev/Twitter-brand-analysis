//
//  SwiftHTTP.h
//  SwiftHTTP
//
//  Created by Austin Cherry on 9/16/14.
//  Copyright (c) 2014 Vluxe. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for SwiftHTTP.
FOUNDATION_EXPORT double SwiftHTTPVersionNumber;

//! Project version string for SwiftHTTP.
FOUNDATION_EXPORT const unsigned char SwiftHTTPVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftHTTP/PublicHeader.h>


